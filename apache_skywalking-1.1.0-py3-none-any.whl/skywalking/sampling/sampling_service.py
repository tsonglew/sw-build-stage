#
# Licensed to the Apache Software Foundation (ASF) under one or more
# contributor license agreements.  See the NOTICE file distributed with
# this work for additional information regarding copyright ownership.
# The ASF licenses this file to You under the Apache License, Version 2.0
# (the "License"); you may not use this file except in compliance with
# the License.  You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

from threading import Lock, Thread

from skywalking import config
from skywalking.log import logger
from skywalking.utils.scheduler import Scheduler


class SamplingService(Thread):

    def __init__(self):
        super().__init__(name='samplingService', daemon=True)
        logger.debug('Started sampling service sampling_n_per_3_secs: %d', config.sample_n_per_3_secs)
        self.lock = Lock()
        self.sampling_factor = 0
        self.reset_task = Scheduler.schedule(3 * 1000, self.reset_sampling_factor)

    def try_sampling(self) -> bool:
        with self.lock:
            if self.sampling_factor < config.sample_n_per_3_secs:
                self.sampling_factor += 1
                return True
            return False

    def force_sampled(self) -> None:
        with self.lock:
            self.sampling_factor += 1

    def reset_sampling_factor(self) -> None:
        with self.lock:
            logger.debug('Reset sampling factor')
            self.sampling_factor = 0
